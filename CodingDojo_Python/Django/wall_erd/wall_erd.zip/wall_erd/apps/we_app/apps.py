from __future__ import unicode_literals

from django.apps import AppConfig


class WeAppConfig(AppConfig):
    name = 'we_app'
