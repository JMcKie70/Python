from __future__ import unicode_literals

from django.apps import AppConfig


class DnAppConfig(AppConfig):
    name = 'dn_app'
