from __future__ import unicode_literals

from django.apps import AppConfig


class DbAppConfig(AppConfig):
    name = 'db_app'
