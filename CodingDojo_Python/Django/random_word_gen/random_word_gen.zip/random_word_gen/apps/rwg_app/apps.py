from __future__ import unicode_literals

from django.apps import AppConfig


class RwgAppConfig(AppConfig):
    name = 'rwg_app'
