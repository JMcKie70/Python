from __future__ import unicode_literals

from django.apps import AppConfig


class EvAppConfig(AppConfig):
    name = 'ev_app'
